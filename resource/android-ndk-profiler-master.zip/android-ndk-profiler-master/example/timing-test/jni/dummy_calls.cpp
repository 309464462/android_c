#include <unistd.h>

extern "C" void do_dummy_call_1(void)
{
        sleep(1);
}

extern "C" void do_dummy_call_2(void)
{
        sleep(1);
}
